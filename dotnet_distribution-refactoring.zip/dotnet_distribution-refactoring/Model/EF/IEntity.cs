﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace DistributionAPI.Model
{
    public interface IEntity
    {
        Guid Id { get; set; }
    }
}
